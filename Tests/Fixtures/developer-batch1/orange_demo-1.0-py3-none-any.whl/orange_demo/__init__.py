"""Orange demo — not executed."""
VERSION = "1.0"
