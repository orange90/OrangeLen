let value = 2 // 中文 👩🏽‍💻
